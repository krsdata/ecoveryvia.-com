<?php
/*echo '<pre>';
print_r($_SERVER);  die;*/
header('location:manage-user.php');
?>