<?php $curPage='user';
$curSubPage='view_user'; 
include("includes/header.php");

?>

<center>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<p></p>
<p style="color:red" align="center"> <h1>Welcome to admin panel</h1> </p>
</center>

 
