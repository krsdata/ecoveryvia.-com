<?php
	define('INDEX','index.php');
	define('ABOUT','about.php');
	define('MANAGECATS','manage_cats.php');
	define('MANAGEIMGS','manage_imgs.php');
	define('ADDCATS','add_cats.php');
	define('ADDCATRES','add_cat_res.php');
	define('PROD_DETAILS','prod_details.php');
	define('CONTACT','contact.php');
	define('SITEMAP','sitemap.php');
	define('PRODUCTS','products.php');
	define('PRODDETAIL','prod_details.php');
	define('CATEGORY','cats.php');
	define('TILECATEGORY','tilecats.php');
	define('GALLERY','gallery.php');



	/*define('INDEX','index');
	define('ABOUT','About-us');
	define('CATEGORY','Category');
	define('PROD_DETAILS','Product-details');
	define('CONTACT','Contact-us');
	define('SITEMAP','Aggieland-Carpet-One-Sitemap');
	define('PRODUCTS','Aggieland-Carpet-One-Products');*/
	
	define('HEADER_TPL','header.tpl');
	define('FRONTHEADER_TPL','front_header.tpl');
	define('GALHEADER_TPL','gal_header.tpl');
	define('ADMIN_LEFT_TPL','admin_left.tpl');
	define('FOOTER_TPL','footer.tpl');
	define('FRONTFOOTER_TPL','front_footer.tpl');
	define('HOME_TPL','home.tpl');
	define('ABOUT_TPL','about.tpl');
	define('LEFTNAV_TPL','leftnav.tpl');
	define('CATEGORY_TPL','cat.tpl');
	define('CATFORM_TPL','catform.tpl');
	define('PRODUCT_TPL','prod.tpl');
	define('COMMON_TPL','common.tpl');
?>