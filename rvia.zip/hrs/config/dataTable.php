<?php
	define('TBL_USER','tbl_user');
	define('TBL_ADMIN','tbl_admin');
	define('TBL_PAGE','tbl_pages');
	define('TBL_SELFIE_USER','tbl_selfie_user');
	define('TBL_MYCAREER','tbl_selfie_mycareer');
	define('TBL_LIKE_COUNT','tbl_selfie_likecount');
	define('TBL_CLIENT_CASE','client_records');
	
	
	
?>