﻿<!-- #header end -->
<!-- Slider start -->
<section id="slider" class=" clearfix slider-height " >
<div class="swiper-container swiper-parent">
    <div class="swiper-wrapper">
        
         <div class="swiper-slide dark  special-recommendation" >
            <div class="container clearfix">
               
            </div>
        </div> 
    </div>
  
  </div>
 
</section>

<!-- Content
        ============================================= -->
<section id="content">
          <div class="content-wrap">
    <div class="promo promo-dark promo-full landing-promo header-stick ">
              <div class="container clearfix ">
        <p style="color:#008000 ; margin:0 !important;">
                                  </p>
        <div class="vertical" style="display:none;">
                 
                </div>
        <h3 class="" style="margin-top:0px !important;">Call us @ <span>+91-731-4700447</span> or Email :<span>info@heavenresearchsecurity.com</span>
                  <div class="col_one_fifth col_last nobottommargin pull-right">
            <a class='inline' href="#inline_content"  ><button class="btn btn-lg btn-danger btn-block nomargin " id="toggle-form" value="submit" style="">Start Trial</button></a>
           </div>
                </h3>
      </div>
            </div>
  </div>

<!-- pricing section-->
  <div class="pricing bottommargin clearfix">
      <div class="container clear-bottommargin clearfix">
          <div class="col-md-12 " >

              <div class="pricing-box">
                  <div class="pricing-title">
                      <h2>Special Recommendation</h2>
                  </div>
                  
                  <div class="pricing-features pastrecord">
                    <div class="spclrecom">
                    <div class="col-md-12">
                      <p>
                        In our special services we provide recommendation to those traders who are interested to trade under Islamic regulations for financial market. According to Islamic constitution participating on every financial market and system is ban. There are some selected indexes in which Islamic constitution allowed to trade.NSE Shariah index is one of them.
                      </p>
                    </div>
                    <div class="col-md-12">
                      <p>
                        Construct Socially Responsible Investment (SRI) products that are attractive to investors who do not wish to invest in stocks of companies that engage in activities that they deem to be against their beliefs. Shariah compliant products are particularly attractive to Islamic investors, as these instruments allow followers of the Islamic faith to invest without violating their religious principles.
                         </p>
                    </div>

                    <div class="col-md-12">
                      <p>
                        A ) :-<b> Primary Filter (Industry/ Business activity)</b>

Islam has forbidden certain trades that conflict the basic tenets of Islam. Any such trades are treated as unethical and immoral and hence should not be traded. These industries are filtered and screened out. Following are the types:
                      </p>
                      <table border="1" width="70%" align="center"> 
                      <tbody><tr align="center">
                          <td colspan="2"><h4><b>Non-Compliant Industries</b></h4></td>
                            
                        </tr>
                        <tr align="center">
                          <td colspan="2" bgcolor="#1abc9c" style=" color:#FFF !important;"><b>Completely Prohibited (Haram) Industries</b></td>
                            
                        </tr>
                        <tr bgcolor="#f6f6f6">
                          <td width="10%" align="center"><b>1</b></td>
                            <td width="90%">Banks / NBFCs / Securities / Commodities Trading  / Casions</td>
                        </tr>
                        <tr>
                          <td width="10%" align="center"><b>2</b></td>
                            <td width="90%">Breweries / Distilleries</td>
                        </tr>
                        <tr bgcolor="#f6f6f6">
                          <td width="10%" align="center"><b>3</b></td>
                            <td width="90%">Chemicals-Alcohol based</td>
                        </tr>
                        <tr>
                          <td width="10%" align="center"><b>4</b></td>
                            <td width="90%">Tobacco-Cigarettes / Pan masala / Chewing Tobacco</td>
                        </tr>
                        <tr bgcolor="#f6f6f6">
                          <td width="10%" align="center"><b>5</b></td>
                            <td width="90%">Advertise and Media (Excluding Print,Television Media and Newspapers)</td>
                        </tr>
                        <tr>
                          <td width="10%" align="center"><b>6</b></td>
                            <td width="90%">Casinos,Gaming Zones and Parlours</td>
                        </tr>
                    </tbody></table>
                    </div>
                    <div class="col-md-12">
                        <p>
                          B ) :- <b> Secondary Filter (Financial Ratios) </b>

Stocks that pass the primary filter are subject to a secondary filter, that of “Financial Ratios”. These Financial Ratios are mandated by select Shariah scholars and are an interpretation from the Shariah Law. Here, the stocks of Companies are screened for Debt, Cash and Interest bearing securities, and Receivable levels, as against their Trailing Twelve Months (TTM) Market cap. Explained below:
                        </p>
                        <table border="1" width="70%" align="center"> 
                      
                        <tbody><tr align="center">
                          <td colspan="2" bgcolor="#1abc9c" style=" color:#FFF !important;"><b>Financial Ratios</b></td>
                            
                        </tr>
                        <tr bgcolor="#f6f6f6">
                          <td width="10%" align="center"><b>1</b></td>
                            <td width="90%">Total Dept to Average TTM Market Cap less than 33%</td>
                        </tr>
                        <tr>
                          <td width="10%" align="center"><b>2</b></td>
                            <td width="90%">Cash+Interest bearing Investments to Average TTM Market Cap less than 33%</td>
                        </tr>
                        <tr bgcolor="#f6f6f6">
                          <td width="10%" align="center"><b>3</b></td>
                            <td width="90%">Sundry Debtors to Average TTM Market Cap less than 33%</td>
                        </tr>
                        <tr>
                          <td width="10%" align="center"><b>4</b></td>
                            <td width="90%">Interest Income to Total Income less than 5%</td>
                        </tr>
                    </tbody></table>
                      </div>
                  </div>

                  </div>
              </div>
          </div>
      </div>  
  </div> 
 
    <!-- end-->
    <style type="text/css">
    .spclrecom {
  background: buttonface none repeat scroll 0 0;
  float: left;
  font-size: larger;
  margin-top: 20px;
  padding: 10px;
  text-align: justify;
}
.pastrecord table tbody tr td {
  padding: 1px !important; 
}
    </style>

 