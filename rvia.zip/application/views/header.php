<!DOCTYPE html>
<html  lang="en-US">
    <head>
        <title>Heaven Research Security : Financial investment advisory in indore,India </title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font.css" type="text/css" />  
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/style.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/dark.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/animate.css" type="text/css" />
        <!--  <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/responsive.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/font/css/font-awesome.min.css"   />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/custom.css"   />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/colorbox.css"   />
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo base_url(); ?>assets/images/favicon-32x32.png">
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
        
       <script src="<?php echo base_url(); ?>assets/js/jquery.newstape.js"></script> 
        
        <script>
         $(function() {
                 $('.newstape').newstape();  
                $("#toggle-form").click(function(){
                $(".vertical").toggle("slow");
                });
            });
        </script> 
      
    
    </head>
 
<body class="stretched">
    <p   class="loading">Loading...</p>

    <!--- =========== popup ===-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootbox.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins.js"></script> 


<!-- Document Wrapper
    ============================================= -->
    <div id="wrapper" class="clearfix">

    <!-- Header
        ============================================= -->
    <header id="header" class="transparent-header page-section dark">
          <div id="header-wrap">
    <div class="container clearfix">
        <div id="primary-menu-trigger"><i class="icon-reorder"></i></div>
  <!-- Logo ============================================= -->
      <div id="logo"> <a href="<?php echo base_url(); ?>" class="standard-logo" data-dark-logo="<?php echo base_url(); ?>assets/images/logo-dark.png"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Canvas Logo"></a> <a href="<?php echo base_url(); ?>" class="retina-logo" data-dark-logo="<?php echo base_url(); ?>assets/images/logo-dark@2x.png"><img src="<?php echo base_url(); ?>assets/images/logo@2x.png" alt="Canvas Logo"></a> </div>
        <!-- #logo end --> 
              
        <!-- Primary Navigation
                    ============================================= -->
       
            <nav id="primary-menu">
                <ul class="one-page-menu">
                    <li class="current"><a href="<?php echo base_url(); ?>" data-href="#header"><div>Home</div></a></li>
                    <li><a href="<?php echo base_url(); ?>index.php/company-profile" data-href="#section-features"><div>About Us</div></a></li>
                    <li><a href="<?php echo base_url(); ?>index.php/services" data-href="#section-pricing" ><div>Services</div></a> </li>
                    <li><a href="<?php echo base_url(); ?>index.php/pricing" data-href="#section-testimonials"><div>Pricing</div></a></li>
                    <li><a href="<?php echo base_url(); ?>index.php/payment" data-href="#section-specs"><div>Payment</div></a></li>
                    <li><a class='inline' href="#inline_content"  ><div>Free Trial</div></a></li>
                    <li><a href="<?php echo base_url(); ?>index.php/past-performance" data-href="#section-specs"><div>Performance </div></a></li>
                                
                    <li><a href="<?php echo base_url(); ?>index.php/contact-us"><div>Contact</div></a></li>
                </ul>
            </nav>              <!-- #primary-menu end --> 
        </div>
    </div>
</header>   
<!-- #header end -->
<!-- Slider start -->