﻿<!-- #header end -->
<!-- Slider start -->
<section id="slider" class=" clearfix slider-height " >
<div class="swiper-container swiper-parent">
    <div class="swiper-wrapper">
        
         <div class="swiper-slide dark complain-suggestion" >
            <div class="container clearfix">
               
            </div>
        </div> 
    </div>
  
  </div>
 
</section>

<!-- Content
        ============================================= -->
<section id="content">
<div class="content-wrap">
    <div class="promo promo-dark promo-full landing-promo header-stick ">
              <div class="container clearfix ">
        <p style="color:#008000 ; margin:0 !important;">
                                  </p>
        <div class="vertical" style="display:none;">
                 
                </div>
        <h3 class="" style="margin-top:0px !important;">Call us @ <span>+91-731-4700447</span> or Email :<span>info@heavenresearchsecurity.com</span>
                  <div class="col_one_fifth col_last nobottommargin pull-right">
            <a class='inline' href="#inline_content"  ><button class="btn btn-lg btn-danger btn-block nomargin " id="toggle-form" value="submit" style="">Start Trial</button></a>
           </div>
                </h3>
      </div>
            </div>
  </div>

<!-- pricing section-->
                <div class="pricing bottommargin clearfix">
                    <div class="container clear-bottommargin clearfix">
                        <div class="col-md-12 " >

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h2>Disclaimer Policy</h2>
                                     
                                </div>
                              
                              <div class="pricing-features pastrecord">
                                <div class="cpln">
                                 <p>
                                  The information contained in this website is for general information purposes only. The information is provided by [business name] and while we endeavour to keep the information up to date and correct, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website or the information, products, services, or related graphics contained on the website for any purpose. Any reliance you place on such information is therefore strictly at your own risk.
                                 </p>
                                 <p>
                                  In no event will we be liable for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data or profits arising out of, or in connection with, the use of this website.
                                 </p>
                                 <p>
                                  Through this website you are able to link to other websites which are not under the control of [business name]. We have no control over the nature, content and availability of those sites. The inclusion of any links does not necessarily imply a recommendation or endorse the views expressed within them.
                                 </p>
                                 <p>
                                  Every effort is made to keep the website up and running smoothly. However, [business name] takes no responsibility for, and will not be liable for, the website being temporarily unavailable due to technical issues beyond our control.
                                 </p>
                                 <p>
                                 <b> INVESTMENT PERFORMANCE / RISK WARNING</b> <br>
Past performance is not indicative of future performance. The value of investments can fall as well as rise and investors may not get back the amount originally invested. An investment in a currency other than the investor's own base currency will be subject to the movement of foreign exchange rates which may cause an additional favourable or unfavourable change in the value of investment. Interest rates, market conditions, special offers, tax rulings and other investment factors are subject to sometimes rapid change.

                                 </p>
                                 </div>
                            </div>
                        </div>
                    </div> 
                      
                </div>
                
            </div>
                    <!-- end-->

<style type="text/css">
.cpln {
  background: buttonface none repeat scroll 0 0;
  border: 1px solid #ccc;
  float: left;
  margin-top: 20px;
  padding: 10px;
  width: 100%;
  font-size: 16px;
  text-align: justify;
}
.pricing-features ul {
    list-style: outside none b;
    margin: 10px 30px;
}
.form-control{ width: 98% !important;  }
</style>

 
         