﻿<!-- #header end -->
<!-- Slider start -->
<section id="slider" class=" clearfix slider-height " >
<div class="swiper-container swiper-parent">
    <div class="swiper-wrapper">
        
         <div class="swiper-slide dark complain-suggestion" >
            <div class="container clearfix">
               
            </div>
        </div> 
    </div>
  
  </div>
 
</section>

<!-- Content
        ============================================= -->
<section id="content">
<div class="content-wrap">
    <div class="promo promo-dark promo-full landing-promo header-stick ">
              <div class="container clearfix ">
        <p style="color:#008000 ; margin:0 !important;">
                                  </p>
        <div class="vertical" style="display:none;">
                 
                </div>
        <h3 class="" style="margin-top:0px !important;">Call us @ <span>+91-731-4700447</span> or Email :<span>info@heavenresearchsecurity.com</span>
                  <div class="col_one_fifth col_last nobottommargin pull-right">
            <a class='inline' href="#inline_content"  ><button class="btn btn-lg btn-danger btn-block nomargin " id="toggle-form" value="submit" style="">Start Trial</button></a>
           </div>
                </h3>
      </div>
            </div>
  </div>

<!-- pricing section-->
                <div class="pricing bottommargin clearfix">
                    <div class="container clear-bottommargin clearfix">
                        <div class="col-md-12 " >

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h2>Complaint & suggestion</h2>
                                    <h3 style="color: white; font-family: caption;">
                                      <?php 
                                        if($comments==1){
                                          echo "Thank you for your feedback !. We will get touch you soon";
                                        }
                                      ?>
                                    </h3>
                                </div>
                              
                              <div class="pricing-features pastrecord">
                                <div class="cpln">
                              Your complaints and suggestions are like “the light of a dark house” for us to improve quality of our services. Feel free to fill our complaint & suggestion form to get frequent response from our HRS complaint team.
                                  
                                </div>
                            </div>
                        </div>
                    </div> 

                     <div class="col-md-12 " >

                        <div class="col-md-8" >
                          <div class="col-md-6" >Name *</div>
                          <div class="col-md-6" >Email *</div>  

                          <div class="col-md-6" > 
                            <input type="text" name="name" class="form-control" required>
                          </div>
                          <div class="col-md-6" > 
                            <input type="email" name="email" class="form-control" required>
                          </div> 
                         <div class="col-md-12" >
                         Comments

                         </div>  

                         <div class="col-md-12" >
                          <textarea class="form-control" rows="6" name="comments"></textarea>
                         </div>
                         <div class="col-md-12" >
                            <div class="col-md-3" >

                              <input type="submit" style="background: rgb(0, 174, 125) none repeat scroll 0% 0%; border: 1px solid rgb(255, 255, 255); color: rgb(255, 255, 255);" name="submit" value="SUBMIT" class="form-control success">
                            </div>
                         </div>
                        </div>

                        <div class="col-md-4" >
                            <div class="col-md-12" style="padding-left: 80px; margin-top: 50px;" >
                          <h2>Our Helpline  </h2>
                          
                           <p>  Phone :+91-731-4700447 </p>
                           <p>  Email : info@heavenresearchsecurity.com</p>
                          </div>
                        </div>


                     </div>



                </div>
                
            </div>
                    <!-- end-->

<style type="text/css">
.cpln {
  background: buttonface none repeat scroll 0 0;
  border: 1px solid #ccc;
  float: left;
  margin-top: 20px;
  width: 100%;
  padding: 10px 0px;
}
.form-control{ width: 98% !important;  }
</style>


         