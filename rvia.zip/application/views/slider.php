<div class="swiper-slide dark" style="background-image: url('<?php echo base_url(); ?>assets/images/banner-1.jpg');">
            <div class="container clearfix">
                <div class="slider-caption slider-caption-center">
                    <h2 data-caption-animate="fadeInUp">Connect With Heaven research</h2>
                </div>
            </div>
        </div>
          
        <div class="swiper-slide dark" style="background-image: url('<?php echo base_url(); ?>assets/images/banner-2.jpg');">
            <div class="container clearfix">
                <div class="slider-caption slider-caption-center">
                     <h2 data-caption-animate="fadeInUp">Have Faith On </h2>
                </div>
            </div>
        </div>
        <div class="swiper-slide dark" style="background-image: url('<?php echo base_url(); ?>assets/images/banner-3.jpg');">
            <div class="container clearfix">
                <div class="slider-caption slider-caption-center">
                    <h2 data-caption-animate="fadeInUp">Be Stand With </h2>
                </div>
            </div>
        </div>
        <div class="swiper-slide dark" style="background-image: url('<?php echo base_url(); ?>assets/images/banner-4.jpg');">
            <div class="container clearfix">
                <div class="slider-caption slider-caption-center">
                    <h2 data-caption-animate="fadeInUp">Share your exciting experience with others</h2>
                </div>
            </div>
        </div>

        <div class="swiper-slide dark" style="background-image: url('<?php echo base_url(); ?>assets/images/banner-5.jpg');">
            <div class="container clearfix">
                <div class="slider-caption slider-caption-center">
                    <h2 data-caption-animate="fadeInUp"> Keep Growing With </h2>
                </div>
            </div>
        </div>
        <div class="swiper-slide dark" style="background-image: url('<?php echo base_url(); ?>assets/images/banner-1.jpg');">
            <div class="container clearfix">
                <div class="slider-caption slider-caption-center">
                    <h2 data-caption-animate="fadeInUp"> Keep Growing With </h2>
                </div>
            </div>
        </div>