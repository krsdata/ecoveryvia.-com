﻿<!-- #header end -->
<!-- Slider start -->
<section id="slider" class=" clearfix slider-height " >
<div class="swiper-container swiper-parent">
    <div class="swiper-wrapper">
        
         <div class="swiper-slide dark complain-suggestion" >
            <div class="container clearfix">
               
            </div>
        </div> 
    </div>
  
  </div>
 
</section>

<!-- Content
        ============================================= -->
<section id="content">
<div class="content-wrap">
    <div class="promo promo-dark promo-full landing-promo header-stick ">
              <div class="container clearfix ">
        <p style="color:#008000 ; margin:0 !important;">
                                  </p>
        <div class="vertical" style="display:none;">
                 
                </div>
        <h3 class="" style="margin-top:0px !important;">Call us @ <span>+91-731-4700447</span> or Email :<span>info@heavenresearchsecurity.com</span>
                  <div class="col_one_fifth col_last nobottommargin pull-right">
            <a class='inline' href="#inline_content"  ><button class="btn btn-lg btn-danger btn-block nomargin " id="toggle-form" value="submit" style="">Start Trial</button></a>
           </div>
                </h3>
      </div>
            </div>
  </div>

<!-- pricing section-->
                <div class="pricing bottommargin clearfix">
                    <div class="container clear-bottommargin clearfix">
                        <div class="col-md-12 " >

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h2>Terms and conditions </h2>
                                     
                                </div>
                              
                              <div class="pricing-features pastrecord">
                                <div class="cpln">
                                  Welcome to our website. If you continue to browse and use this website, you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern heaven research security advisory relationship with you in relation to this website. If you disagree with any part of these terms and conditions, please do not use our website.
The term advisory or ‘us’ or ‘we’ refers to the owner of the website whose registered office is Navlakha, p. k corporation, indore 452001. 
The use of this website is subject to the following terms of use: 
<ul>
 <li> The content of the pages of this website is for your general information and use only. It is subject to change without notice. </li>
<li> This website uses cookies to monitor browsing preferences. If you do allow cookies to be used, the following personal information may be stored by us for use by third parties: </li>
<li> Neither we nor any third parties provide any warranty or guarantee as to the accuracy, timeliness, performance, completeness or suitability of the information and materials found or offered on this website for any particular purpose. You acknowledge that such information and materials may contain inaccuracies or errors and we expressly exclude liability for any such inaccuracies or errors to the fullest extent permitted by law.</li>
<li> Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services or information available through this website meet your specific requirements.</li>
<li> This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.</li>
<li> All trademarks reproduced in this website, which are not the property of, or licensed to the operator, are acknowledged on the website.</li>
<li> Unauthorised use of this website may give rise to a claim for damages and/or be a criminal offence.</li>
<li> From time to time, this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).</li>
<li> Your use of this website and any dispute arising out of such use of the website is subject to the laws of England, Northern Ireland, Scotland and Wales.<br>
</ul>
                                 </div>
                            </div>
                        </div>
                    </div> 
                    
                </div>
                
            </div>
                    <!-- end-->

<style type="text/css">
.cpln {
  background: buttonface none repeat scroll 0 0;
  border: 1px solid #ccc;
  float: left;
  margin-top: 20px;
  padding: 10px;
  width: 100%;
  font-size: 16px;
  text-align: justify;
}
.pricing-features ul {
    list-style: outside none b;
    margin: 10px 30px;
}
.form-control{ width: 98% !important;  }
</style>        