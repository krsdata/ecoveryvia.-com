﻿<!-- #header end -->
<!-- Slider start -->
<section id="slider" class=" clearfix slider-height " >
<div class="swiper-container swiper-parent">
    <div class="swiper-wrapper">
        
         <div class="swiper-slide dark free-trial-slide2" >
            <div class="container clearfix">
            </div>
        </div> 
    </div>
  
  </div>
 
</section>

<!-- Content
        ============================================= -->
<section id="content">
          <div class="content-wrap">
    <div class="promo promo-dark promo-full landing-promo header-stick ">
              <div class="container clearfix ">
        <p style="color:#008000 ; margin:0 !important;">
                                  </p>
        <div class="vertical" style="display:none;">
                  <form action="action/homemail.php" method="post" role="form" class=" clearfix">
            <div class="col_four_fifth nobottommargin">
                      <div class="col_one_third nobottommargin">
                <input type="text" class="form-control input-lg not-dark" value="" name="name" placeholder="Your Name*">
              </div>
                      <div class="col_one_third nobottommargin">
                <input type="email" class="form-control input-lg not-dark" value="" name="email" placeholder="Your Email*">
              </div>
                      <div class="col_one_third col_last nobottommargin">
                <input type="text" class="form-control input-lg not-dark" value="" name="mobile" placeholder="Contact Number*">
              </div>
                    </div>
            <div class="col_one_fifth col_last nobottommargin">
                      <button class="btn btn-lg btn-danger btn-block nomargin" value="submit" name="submit" type="submit" style="">SUBMIT</button>
                    </div>
          </form>
                </div>
        <h3 class="" style="margin-top:0px !important;">Call us @ <span>+91-731-4700447</span> or Email :<span>info@heavenresearchsecurity.com</span>
                  <div class="col_one_fifth col_last nobottommargin pull-right">
            <button class="btn btn-lg btn-danger btn-block nomargin " id="toggle-form" value="submit" style="">START FREE TRIAL</button>
          </div>
                </h3>
      </div>
            </div>
  </div>

<!-- pricing section-->
 
<div class="pricing bottommargin clearfix">
                    <div class="container clear-bottommargin clearfix">
                        <div class="col-md-12 " >

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>Stock Cash</h4>
                                </div>
                                
                                <div class="pricing-features">
                                   <table border="1" width="100%">
                                    <tr>
                                        <td colspan="4" class="stock_title">NORMAL CASH</td>
                                    </tr>
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 10000</td>
                                            <td>INR 25000</td>
                                            <td>INR 50000</td>
                                            <td>INR 90000</td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL CASH">
                                                <input type="hidden" name="prodPrice" value="10000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL CASH">
                                                <input type="hidden" name="prodPrice" value="25000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL CASH">
                                                <input type="hidden" name="prodPrice" value="50000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL CASH">
                                                <input type="hidden" name="prodPrice" value="90000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>
                                         <tr>
                                        <td colspan="4" class="stock_title">CASH HNI</td>
                                    </tr>
                                        <tr >
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 20000</td>
                                            <td>INR 50000</td>
                                            <td>INR 100000</td>
                                            <td>INR 125000</td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="CASH HNI">
                                                <input type="hidden" name="prodPrice" value="20000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="CASH HNI">
                                                <input type="hidden" name="prodPrice" value="50000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="CASH HNI">
                                                <input type="hidden" name="prodPrice" value="100000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="CASH HNI">
                                                <input type="hidden" name="prodPrice" value="125000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                           <tr>
                                        <td colspan="4" class="stock_title">HRS POWER</td>
                                    </tr>
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 35000</td>
                                            <td>INR 100000</td>
                                            <td>INR 200000</td>
                                            <td>INR 400000</td>
                                        </tr>

                                        <tr>
                                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="35000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="100000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="200000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td><a href="#"> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="400000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></a></td>
                                        </tr>

                                   </table>

                                </div>
                                
                            </div>

                        </div>
                        
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>Stock Future </h4>
                                </div>
                                
                                <div class="pricing-features"> 
                                    <table border="1" width="100%">
                                    <tr>
                                        <td colspan="4" class="stock_title">NORMAL FUTURE</td>
                                    </tr>
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td class="price_title">INR 10000</td>
                                            <td>INR 25000</td>
                                            <td>INR 45000</td>
                                            <td>INR 85000</td>
                                        </tr>

                                        <tr>
                                            <td >
                                            <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL FUTURE">
                                                <input type="hidden" name="prodPrice" value="10000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                            </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL FUTURE">
                                                <input type="hidden" name="prodPrice" value="25000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL FUTURE">
                                                <input type="hidden" name="prodPrice" value="45000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL FUTURE">
                                                <input type="hidden" name="prodPrice" value="85000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>
                                         <tr>
                                        <td colspan="4" class="stock_title">FUTURE HNI</td>
                                    </tr>
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 25000</td>
                                            <td>INR 60000</td>
                                            <td>INR 120000</td>
                                            <td>INR 150000</td>

                                        </tr>

                                        <tr>
                                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE HNI">
                                                <input type="hidden" name="prodPrice" value="25000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE HNI">
                                                <input type="hidden" name="prodPrice" value="60000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE HNI">
                                                <input type="hidden" name="prodPrice" value="120000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE HNI">
                                                <input type="hidden" name="prodPrice" value="150000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                           <tr>
                                        <td colspan="4" class="stock_title">FUTURE POWER</td>
                                    </tr>
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr>
                                            <td>INR 50000</td>
                                            <td>INR 140000</td>
                                            <td>INR 2250000</td>
                                            <td>INR 500000</td>
                                        </tr>

                                        <tr>
                                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE POWER">
                                                <input type="hidden" name="prodPrice" value="50000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE POWER">
                                                <input type="hidden" name="prodPrice" value="140000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE POWER">
                                                <input type="hidden" name="prodPrice" value="2250000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE POWER">
                                                <input type="hidden" name="prodPrice" value="500000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                   </table>
                                     
                                </div>
                                
                            </div>

                        </div>
                        
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>OPTION </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    <table border="1" width="100%">
                                    <tr>
                                        <td colspan="4" class="stock_title">NORMAL OPTION</td>
                                    </tr>
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 10000</td>
                                            <td>INR 25000</td>
                                            <td>INR 50000</td>
                                            <td>INR 100000</td>
                                        </tr>

                                        <tr>
                                            <td >
                                                 <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL OPTION">
                                                <input type="hidden" name="prodPrice" value="10000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL OPTION">
                                                <input type="hidden" name="prodPrice" value="25000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL OPTION">
                                                <input type="hidden" name="prodPrice" value="50000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL OPTION">
                                                <input type="hidden" name="prodPrice" value="100000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>
                                         <tr>
                                        <td colspan="4" class="stock_title">OPTION HNI</td>
                                    </tr>
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 15000</td>
                                            <td>INR 40000</td>
                                            <td>INR 80000</td>
                                            <td>INR 150000</td>

                                                                                    </tr>

                                        <tr>
                                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="OPTION HNI">
                                                <input type="hidden" name="prodPrice" value="15000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="OPTION HNI">
                                                <input type="hidden" name="prodPrice" value="40000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="OPTION HNI">
                                                <input type="hidden" name="prodPrice" value="80000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="OPTION HNI">
                                                <input type="hidden" name="prodPrice" value="150000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                           <tr>
                                        <td colspan="4" class="stock_title">NIFTY OPTION</td>
                                    </tr>
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 8000</td>
                                            <td>INR 20000</td>
                                            <td>INR 45000</td>
                                            <td>INR 90000</td>
                                        </tr>

                                        <tr>
                                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY OPTION">
                                                <input type="hidden" name="prodPrice" value="8000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY OPTION">
                                                <input type="hidden" name="prodPrice" value="20000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY OPTION">
                                                <input type="hidden" name="prodPrice" value="45000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY OPTION">
                                                <input type="hidden" name="prodPrice" value="90000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                   </table>
                                </div>
                                
                            </div>

                        </div>
                        
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>NIFTY FUTURE     </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">NIFTY FUTURE</td>
                                         </tr> 
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 8000</td>
                                            <td>INR 20000</td>
                                            <td>INR 45000</td>
                                            <td>INR 90000</td>
                                        </tr>

                                        <tr>
                                            <td >
                                                 <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY FUTURE">
                                                <input type="hidden" name="prodPrice" value="8000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY FUTURE">
                                                <input type="hidden" name="prodPrice" value="20000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY FUTURE">
                                                <input type="hidden" name="prodPrice" value="45000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY FUTURE">
                                                <input type="hidden" name="prodPrice" value="90000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                         <tr>
                                        <td colspan="4" class="stock_title">NIFTY POWER</td>
                                         </tr>
                                    
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 20000</td>
                                            <td>INR 55000</td>
                                            <td>INR 100000</td>
                                            <td>INR 125000</td>
                                        </tr>

                                        <tr>
                                            <td >
                                                 <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="20000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="55000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="100000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY POWER">
                                                <input type="hidden" name="prodPrice" value="125000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>
                                   </table>
                                </div>
                                
                            </div>

                        </div>



                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>COMMODITY   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">COMMODITY( NORMAL)</td>
                                         </tr> 
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 15000</td>
                                            <td>INR 40000</td>
                                            <td>INR 80000</td>
                                            <td>INR 150000</td>
                                        </tr>

                                        <tr>
                                            <td >
                                                 <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY">
                                                <input type="hidden" name="prodPrice" value="15000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY">
                                                <input type="hidden" name="prodPrice" value="40000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY">
                                                <input type="hidden" name="prodPrice" value="80000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY">
                                                <input type="hidden" name="prodPrice" value="150000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                         <tr>
                                        <td colspan="4" class="stock_title">COMMODITY HNI</td>
                                         </tr>
                                    
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 30000</td>
                                            <td>INR 80000</td>
                                            <td>INR 150000</td>
                                            <td>INR 330000</td>
                                        </tr>

                                        <tr>
                                            <td > 

                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY HNI">
                                                <input type="hidden" name="prodPrice" value="30000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY HNI">
                                                <input type="hidden" name="prodPrice" value="80000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                             <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY HNI">
                                                <input type="hidden" name="prodPrice" value="150000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                             <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY HNI">
                                                <input type="hidden" name="prodPrice" value="330000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                        </tr>
                                   </table>
                                </div>
                                
                            </div>

                        </div>
                         <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4  > COMEX   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 20000</td>
                                            <td>INR 50000</td>
                                            <td>INR 100000</td>
                                            <td>INR 220000</td>
                                        </tr>

                                        <tr>
                                            <td >

                                            <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMEX">
                                                <input type="hidden" name="prodPrice" value="20000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>

                                            <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMEX">
                                                <input type="hidden" name="prodPrice" value="50000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMEX">
                                                <input type="hidden" name="prodPrice" value="10000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                         </td>
                                             <td>
                                               <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMEX">
                                                <input type="hidden" name="prodPrice" value="220000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            
                                         </td>

                                        </tr> 
                                   </table>

                                </div>
                                
                            </div>

                        </div>
                         <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>NCDEX   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">NCDEX  NORMAL</td>
                                         </tr> 
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 15000</td>
                                            <td>INR 40000</td>
                                            <td>INR 80000</td>
                                            <td>INR 150000</td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  NORMAL">
                                                <input type="hidden" name="prodPrice" value="15000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  NORMAL">
                                                <input type="hidden" name="prodPrice" value="40000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  NORMAL">
                                                <input type="hidden" name="prodPrice" value="80000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td>  <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  NORMAL">
                                                <input type="hidden" name="prodPrice" value="220000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                        </tr>

                                         <tr>
                                        <td colspan="4">NCDEX HNI</td>
                                         </tr>
                                    
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 25000</td>
                                            <td>INR 70000</td>
                                            <td>INR 125000</td>
                                            <td>INR 250000</td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  HNI">
                                                <input type="hidden" name="prodPrice" value="25000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  HNI">
                                                <input type="hidden" name="prodPrice" value="70000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  HNI">
                                                <input type="hidden" name="prodPrice" value="125000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  HNI">
                                                <input type="hidden" name="prodPrice" value="250000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                        </tr>
                                   </table>
                                </div>
                                
                            </div>

                        </div> 
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>I-FOREX   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">I-FOREX ( INTERNATIONAL )</td>
                                         </tr> 
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 25000</td>
                                            <td>INR 70000</td>
                                            <td>INR 125000</td>
                                            <td>INR 250000</td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="I-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="25000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="I-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="70000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="I-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="125000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="I-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="250000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                        </tr> 
                                   </table>
                                   
                                </div>
                                
                            </div>

                        </div>
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>D-FOREX   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">D-FOREX (INTERNATIONAL)</td>
                                         </tr> 
                                        <tr>
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR 10000</td>
                                            <td>INR 25000</td>
                                            <td>INR 50000</td>
                                            <td>INR 100000</td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="D-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="10000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="D-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="25000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="D-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="50000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="D-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="100000">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                            </td>
                                        </tr> 
                                   </table> 
                                </div> 
                            </div> 
                        </div> 

                    </div>
                </div>
                    <!-- end-->


    <script language="javascript">
    document.onmousedown=disableclick;
    status="Right Click Disabled";
    function disableclick(event)
    {
      if(event.button==2)
       {
        //alert(status);
        // return false;    
       }
    }
    document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 67 || 
             e.keyCode === 86 || 
             e.keyCode === 85 || 
             e.keyCode === 117)) {
           // alert('not allowed');
           // return false;
        } else {
           // return false;
        }
};
    </script>



         