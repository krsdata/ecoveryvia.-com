﻿<!-- #header end -->
<!-- Slider start -->
<section id="slider" class=" clearfix slider-height " >
<div class="swiper-container swiper-parent">
    <div class="swiper-wrapper">
        
         <div class="swiper-slide dark complain-suggestion" >
            <div class="container clearfix">
               
            </div>
        </div> 
    </div>
  
  </div>
 
</section>

<!-- Content
        ============================================= -->
<section id="content">
<div class="content-wrap">
    <div class="promo promo-dark promo-full landing-promo header-stick ">
              <div class="container clearfix ">
        <p style="color:#008000 ; margin:0 !important;">
                                  </p>
        <div class="vertical" style="display:none;">
                 
                </div>
        <h3 class="" style="margin-top:0px !important;">Call us @ <span>+91-731-4700447</span> or Email :<span>info@heavenresearchsecurity.com</span>
                  <div class="col_one_fifth col_last nobottommargin pull-right">
            <a class='inline' href="#inline_content"  ><button class="btn btn-lg btn-danger btn-block nomargin " id="toggle-form" value="submit" style="">Start Trial</button></a>
           </div>
                </h3>
      </div>
            </div>
  </div>

<!-- pricing section-->
                <div class="pricing bottommargin clearfix">
                    <div class="container clear-bottommargin clearfix">
                        <div class="col-md-12 " >

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h2>Refund and Cancellation Policy</h2>
                                     
                                </div>
                              
                              <div class="pricing-features pastrecord">
                                <div class="cpln">
                                  <ul>
                                      <li>The products available for purchase on our web site are downloadable, functional, and try-before-you-buy. We provide free trial periods to let you fully evaluate our products before you make a purchase decision.</li>
                                      <li>Please use the trial period to make sure that the software meets your needs before purchasing a license. All of our software is functional during the trial period. None of our software requires registration to enable its primary functionality.</li>
                                      <li>If you purchase one of our products, after your payment has cleared your license to use the software will be activated. Once the license is activated, no refunds will be given. We have this policy since it would be impossible for you to return your registered version of our software.</li>
                                      <li>During your trial period, our support staff is available to assist in installation and configuration via email or telephone. We strongly recommend that all customers download, install, and test the trial version of any product prior to making a purchase.</li>
                                      <li>In rare instances and only within 30 days of purchase, if due to technical difficulties or platform incompatibilities the software will not function, we may, at our discretion, issue a refund. In such instances, we require that you provide enough information for us to positively identify your purchase transaction (e.g., order number, your company name, date of transaction, purchase code, number of licenses purchased, etc.). If we are able to positively identify your order, and if your request is made within 30 days of purchase, you must submit to us a email or letter of destruction of on-premise software on your company letterhead or company email before we will process the refund. Avankia is not responsible for lost, delayed, or misdirected mail or email, delays for downloading, or other communication system delays.</li>
                                      <li><b>Acceptance of this Refund Policy</b> <br>
It is your responsibility to familiarize yourself with this refund policy. By placing an order for any of our products, you indicate that you have read this refund policy and that you agree with and fully accept the terms of this refund policy.
If you do not agree with or fully accept the terms of this refund policy, we ask that you do not place an order with us.
</li>
                                      <li>Please contact customer service at 0731-4700447 or email at  info@heavenresearchsecurity.com  if you have any questions.</li>
                                  </ul>
                                  </div>
                            </div>
                        </div>
                    </div> 
                    


                </div>
                
            </div>
                    <!-- end-->

<style type="text/css">
.cpln {
  background: buttonface none repeat scroll 0 0;
  border: 1px solid #ccc;
  float: left;
  margin-top: 20px;
  padding: 10px;
  width: 100%;
  font-size: 16px;
  text-align: justify;
}
.form-control{ width: 98% !important;  }
</style>

 
         