﻿<!-- #header end -->
<!-- Slider start -->
<?php 
    
    $CI             =   & get_instance();

  
  
   /* $hrs_power      =  $CI->get_pricing('HRS POWER');

    $normal_future  =  $CI->get_pricing('NORMAL FUTURE');
    $future_hni     =  $CI->get_pricing('FUTURE HNI');
    $future_power   =  $CI->get_pricing('FUTURE POWER');

    $normal_option  =  $CI->get_pricing('NORMAL OPTION');
    $option_hni     =  $CI->get_pricing('OPTION HNI');
    $nifty_option   =  $CI->get_pricing('NIFTY OPTION');

    $nifty_future   =  $CI->get_pricing('NIFTY FUTURE');
    $nifty_power    =  $CI->get_pricing('NIFTY POWER');

    $commodity_normal =  $CI->get_pricing('COMMODITY(NORMAL)');
    $commodity_hni    =  $CI->get_pricing('COMMODITY HNI');

    $comex          =  $CI->get_pricing('COMEX');
    $ncdex_normal   =  $CI->get_pricing('NCDEX NORMAL');
    $ncdex_hni      =  $CI->get_pricing('NCDEX HNI');
    $i_forex        =  $CI->get_pricing('I-FOREX');
    $d_forex        =  $CI->get_pricing('D-FOREX');*/



  

?>

<section id="slider" class=" clearfix slider-height " >
<div class="swiper-container swiper-parent">
    <div class="swiper-wrapper">
        
         <div class="swiper-slide dark princing-slide" >
            <div class="container clearfix">
                
            </div>
        </div> 
    </div>
  
  </div>
 
</section>

<!-- Content
        ============================================= -->
<section id="content">
          <div class="content-wrap">
    <div class="promo promo-dark promo-full landing-promo header-stick ">
              <div class="container clearfix ">
        <p style="color:#008000 ; margin:0 !important;">
                                  </p>
        
        <h3 class="" style="margin-top:0px !important;">Call us @ <span>+91-731-4700447</span> or Email :<span>info@heavenresearchsecurity.com</span>
                  <div class="col_one_fifth col_last nobottommargin pull-right">
            <a class='inline' href="#inline_content"  ><button class="btn btn-lg btn-danger btn-block nomargin " id="toggle-form" value="submit" style="">START FREE TRIAL</button></a>
          </div>
                </h3>
      </div>
            </div>
  </div>

<!-- pricing section-->
 
<div class="pricing bottommargin clearfix">
    <div class="container clear-bottommargin clearfix ">
        <div class="col-md-12 " >

            <div class="pricing-box">
                <div class="pricing-title">
                    <h4>Stock Cash</h4>
                </div>
                
                <div class="pricing-features">
                   <table border="1" width="100%">
                    <tr>
                        <td colspan="4" class="stock_title">NORMAL CASH</td>
                    </tr>
                        <tr class="priceduration">
                            <td><strong>Monthly</strong></td>
                            <td><strong>Quaterly</strong></td>
                            <td><strong>Half yearly</strong></td>
                            <td><strong>Yearly</strong></td>
                        </tr>

                        <tr class="price_title">

                            <td>INR <?php $CI->get_pricing('NORMAL CASH','Monthely'); ?></td>
                            <td>INR <?php $CI->get_pricing('NORMAL CASH','Quaterly'); ?></td>
                            <td>INR <?php $CI->get_pricing('NORMAL CASH','Halfyearly'); ?></td>
                            <td>INR <?php $CI->get_pricing('NORMAL CASH','Yearly'); ?></td>
                        </tr>

                        <tr>
                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="NORMAL CASH">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL CASH','Monthely'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="NORMAL CASH">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL CASH','Quaterly'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="NORMAL CASH">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL CASH','Halfyearly'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="NORMAL CASH">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL CASH','Monthely'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                        </tr>
                         <tr>
                        <td colspan="4" class="stock_title">CASH HNI</td>
                    </tr>
                        <tr class="priceduration">
                            <td><strong>Monthly</strong></td>
                            <td><strong>Quaterly</strong></td>
                            <td><strong>Half yearly</strong></td>
                            <td><strong>Yearly</strong></td>
                        </tr>
                        <tr class="price_title">
                            <td>INR <?php $CI->get_pricing('CASH HNI','Monthely'); ?></td>
                            <td>INR <?php $CI->get_pricing('CASH HNI','Quaterly'); ?></td>
                            <td>INR <?php $CI->get_pricing('CASH HNI','Halfyearly'); ?></td>
                            <td>INR <?php $CI->get_pricing('CASH HNI','Yearly'); ?></td>
                       
                        </tr>

                        <tr>
                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="CASH HNI">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('CASH HNI','Monthely'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="CASH HNI">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('CASH HNI','Quaterly'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="CASH HNI">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('CASH HNI','Halfyearly'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="CASH HNI">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('CASH HNI','Yearly'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                        </tr>

                           <tr>
                        <td colspan="4" class="stock_title">HRS POWER</td>
                    </tr>
                        <tr class="priceduration">
                            <td><strong>Monthly</strong></td>
                            <td><strong>Quaterly</strong></td>
                            <td><strong>Half yearly</strong></td>
                            <td><strong>Yearly</strong></td>
                        </tr>
                        <tr class="price_title">
                            <td>INR <?php $CI->get_pricing('HRS POWER','Monthely'); ?></td>
                            <td>INR <?php $CI->get_pricing('HRS POWER','Quaterly'); ?></td>
                            <td>INR <?php $CI->get_pricing('HRS POWER','Halfyearly'); ?></td>
                            <td>INR <?php $CI->get_pricing('HRS POWER','Yearly'); ?></td>
                       
                        </tr>

                        <tr>
                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="HRS POWER">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('HRS POWER','Monthely'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="HRS POWER">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('HRS POWER','Quaterly'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="HRS POWER">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('HRS POWER','Halfyearly'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></td>
                            <td><a href="#"> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                <input type="hidden" name="prodName" value="HRS POWER">
                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('HRS POWER','Yearly'); ?>">
                                <input type="hidden" name="prodQty" value="1">
                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                <input type="hidden" name="shippingUnits" value="1">
                                <input type="submit" name="submit" value="Pay Now">
                             </form></a></td>
                        </tr>

                   </table>

                </div>
                
            </div>

        </div>
                        
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>Stock Future </h4>
                                </div>
                                
                                <div class="pricing-features"> 
                                    <table border="1" width="100%">
                                    <tr>
                                        <td colspan="4" class="stock_title">NORMAL FUTURE</td>
                                    </tr>
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td class="price_title"> <?php $CI->get_pricing('NORMAL FUTURE','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NORMAL FUTURE','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NORMAL FUTURE','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NORMAL FUTURE','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td >
                                            <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL FUTURE">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL FUTURE','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                            </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL FUTURE">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL FUTURE','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL FUTURE">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL FUTURE','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL FUTURE">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL FUTURE','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>
                                         <tr>
                                        <td colspan="4" class="stock_title">FUTURE HNI</td>
                                    </tr>
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR <?php $CI->get_pricing('FUTURE HNI','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('FUTURE HNI','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('FUTURE HNI','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('FUTURE HNI','Yearly'); ?></td>

                                        </tr>

                                        <tr>
                                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('FUTURE HNI','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('FUTURE HNI','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('FUTURE HNI','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('FUTURE HNI','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                           <tr>
                                        <td colspan="4" class="stock_title">FUTURE POWER</td>
                                    </tr>
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr>
                                            <td>INR <?php $CI->get_pricing('FUTURE POWER','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('FUTURE POWER','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('FUTURE POWER','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('FUTURE POWER','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE POWER">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('FUTURE POWER','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE POWER">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('FUTURE POWER','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE POWER">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('FUTURE POWER','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="FUTURE POWER">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('FUTURE POWER','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                   </table>
                                     
                                </div>
                                
                            </div>

                        </div>
                        
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>OPTION </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    <table border="1" width="100%">
                                    <tr>
                                        <td colspan="4" class="stock_title">NORMAL OPTION</td>
                                    </tr>
                                        <tr class="priceduration" >
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR <?php $CI->get_pricing('NORMAL OPTION','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NORMAL OPTION','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NORMAL OPTION','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NORMAL OPTION','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td >
                                                 <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL OPTION">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL OPTION','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL OPTION">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL OPTION','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL OPTION">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL OPTION','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NORMAL OPTION">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NORMAL OPTION','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>
                                         <tr>
                                        <td colspan="4" class="stock_title">OPTION HNI</td>
                                    </tr>
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR <?php $CI->get_pricing('OPTION HNI','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('OPTION HNI','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('OPTION HNI','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('OPTION HNI','Yearly'); ?></td>

                                        </tr>

                                        <tr>
                                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="OPTION HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('OPTION HNI','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="OPTION HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('OPTION HNI','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="OPTION HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('OPTION HNI','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="OPTION HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('OPTION HNI','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                           <tr>
                                        <td colspan="4" class="stock_title">NIFTY OPTION</td>
                                    </tr>
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                           <td>INR <?php $CI->get_pricing('NIFTY OPTION','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NIFTY OPTION','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NIFTY OPTION','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NIFTY OPTION','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td > <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY OPTION">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY OPTION','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY OPTION">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY OPTION','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY OPTION">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY OPTION','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY OPTION">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY OPTION','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                   </table>
                                </div>
                                
                            </div>

                        </div>
                        
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>NIFTY FUTURE     </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">NIFTY FUTURE</td>
                                         </tr> 
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                           <td>INR <?php $CI->get_pricing('NIFTY FUTURE','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NIFTY FUTURE','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NIFTY FUTURE','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NIFTY FUTURE','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td >
                                                 <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY FUTURE">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY FUTURE','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY FUTURE">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY FUTURE','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY FUTURE">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY FUTURE','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY FUTURE">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY FUTURE','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                         <tr>
                                        <td colspan="4" class="stock_title">NIFTY POWER</td>
                                         </tr>
                                    
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR <?php $CI->get_pricing('NIFTY POWER','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NIFTY POWER','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NIFTY POWER','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NIFTY POWER','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td >
                                                 <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY POWER','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY POWER','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="HRS POWER">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY POWER','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NIFTY POWER">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NIFTY POWER','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>
                                   </table>
                                </div>
                                
                            </div>

                        </div>



                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>COMMODITY   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">COMMODITY(NORMAL)</td>
                                         </tr> 
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">

                                            <td>INR <?php $CI->get_pricing('COMMODITY(NORMAL)','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('COMMODITY(NORMAL)','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('COMMODITY(NORMAL)','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('COMMODITY(NORMAL)','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td >
                                                 <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMMODITY(NORMAL)','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMMODITY(NORMAL)','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMMODITY(NORMAL)','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                            <td> <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMMODITY(NORMAL)','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form></td>
                                        </tr>

                                         <tr>
                                        <td colspan="4" class="stock_title">COMMODITY HNI</td>
                                         </tr>
                                    
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR <?php $CI->get_pricing('COMMODITY HNI','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('COMMODITY HNI','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('COMMODITY HNI','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('COMMODITY HNI','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td > 

                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMMODITY HNI','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMMODITY HNI','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                             <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMMODITY HNI','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                             <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMMODITY HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMMODITY HNI','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                        </tr>
                                   </table>
                                </div>
                                
                            </div>

                        </div>
                         <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4  > COMEX   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR <?php $CI->get_pricing('COMEX','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('COMEX','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('COMEX','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('COMEX','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td >

                                            <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMEX">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMEX','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>

                                            <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMEX">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMEX','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            </td>
                                            <td>
                                              <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMEX">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMEX','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                         </td>
                                             <td>
                                               <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="COMEX">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('COMEX','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                             </form>
                                            
                                         </td>

                                        </tr> 
                                   </table>

                                </div>
                                
                            </div>

                        </div>
                         <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>NCDEX   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">NCDEX  NORMAL</td>
                                         </tr> 
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR <?php $CI->get_pricing('NCDEX  NORMAL','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NCDEX  NORMAL','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NCDEX  NORMAL','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NCDEX  NORMAL','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  NORMAL">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NCDEX  NORMAL','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  NORMAL">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NCDEX  NORMAL','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  NORMAL">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NCDEX  NORMAL','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td>  <form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  NORMAL">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NCDEX  NORMAL','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                        </tr>

                                         <tr>
                                        <td colspan="4">NCDEX HNI</td>
                                         </tr>
                                    
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR <?php $CI->get_pricing('NCDEX HNI','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NCDEX HNI','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NCDEX HNI','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('NCDEX HNI','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NCDEX HNI','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NCDEX HNI','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NCDEX HNI','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="NCDEX  HNI">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('NCDEX HNI','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                        </tr>
                                   </table>
                                </div>
                                
                            </div>

                        </div> 
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>I-FOREX   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">I-FOREX ( INTERNATIONAL )</td>
                                         </tr> 
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                           <td>INR <?php $CI->get_pricing('I-FOREX','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('I-FOREX','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('I-FOREX','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('I-FOREX','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="I-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('I-FOREX','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="I-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('I-FOREX','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="I-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('I-FOREX','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="I-FOREX ( INTERNATIONAL ">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('I-FOREX','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                        </tr> 
                                   </table>
                                   
                                </div>
                                
                            </div>

                        </div>
                        <div class="col-md-12 fadeInLeft animated" data-animate="fadeInLeft">

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>D-FOREX   </h4>
                                </div>
                                
                                <div class="pricing-features">
                                    
                                    <table border="1" width="100%"> 
                                     <tr>
                                        <td colspan="4" class="stock_title">D-FOREX (INTERNATIONAL)</td>
                                         </tr> 
                                        <tr class="priceduration">
                                            <td><strong>Monthly</strong></td>
                                            <td><strong>Quaterly</strong></td>
                                            <td><strong>Half yearly</strong></td>
                                            <td><strong>Yearly</strong></td>
                                        </tr>
                                        <tr class="price_title">
                                            <td>INR <?php $CI->get_pricing('D-FOREX','Monthely'); ?></td>
                                            <td>INR <?php $CI->get_pricing('D-FOREX','Quaterly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('D-FOREX','Halfyearly'); ?></td>
                                            <td>INR <?php $CI->get_pricing('D-FOREX','Yearly'); ?></td>
                                        </tr>

                                        <tr>
                                            <td ><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="D-FOREX ( INTERNATIONAL )">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('D-FOREX','Monthely'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="D-FOREX ( INTERNATIONAL )">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('D-FOREX','Quaterly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="D-FOREX ( INTERNATIONAL )">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('D-FOREX','Halfyearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now"></td>
                                            <td><form action="https://secure.ebs.in/pg/ma/billing/cart/action/add/" method="post">
                                                <input type="hidden" name="accountId" value="f251445dc76c1c35bac5aa963d0ce292MTg0MTc=">
                                                <input type="hidden" name="prodName" value="D-FOREX ( INTERNATIONAL )">
                                                <input type="hidden" name="prodPrice" value="<?php $CI->get_pricing('D-FOREX','Yearly'); ?>">
                                                <input type="hidden" name="prodQty" value="1">
                                                <input type="hidden" name="shopURL" value="aHR0cDovL2hlYXZlbnJlc2VhcmNoc2VjdXJpdHkuY29t">
                                                <input type="hidden" name="shippingUnits" value="1">
                                                <input type="submit" name="submit" value="Pay Now">
                                            </td>
                                        </tr> 
                                   </table> 
                                </div> 
                            </div> 
                        </div> 

                    </div>
                </div>
                    <!-- end-->


    <script language="javascript">
    document.onmousedown=disableclick;
    status="Right Click Disabled";
    function disableclick(event)
    {
      if(event.button==2)
       {
        //alert(status);
        // return false;    
       }
    }
    document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 67 || 
             e.keyCode === 86 || 
             e.keyCode === 85 || 
             e.keyCode === 117)) {
           // alert('not allowed');
           // return false;
        } else {
           // return false;
        }
};
    </script>



         