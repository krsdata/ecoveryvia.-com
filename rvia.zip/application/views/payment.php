﻿<!-- #header end -->
<!-- Slider start -->
<section id="slider" class=" clearfix slider-height " >
<div class="swiper-container swiper-parent">
    <div class="swiper-wrapper">
        
         <div class="swiper-slide dark free-trial-slide" >
            <div class="container clearfix">
                
            </div>
        </div> 
    </div>
  
  </div>
 
</section>

<!-- Content
        ============================================= -->
<section id="content">
          <div class="content-wrap">
    <div class="promo promo-dark promo-full landing-promo header-stick ">
              <div class="container clearfix ">
        <p style="color:#008000 ; margin:0 !important;">
                                  </p>
        <div class="vertical" style="display:none;">
                 
                </div>
        <h3 class="" style="margin-top:0px !important;">Call us @ <span>+91-731-4700447</span> or Email :<span>info@heavenresearchsecurity.com</span>
                  <div class="col_one_fifth col_last nobottommargin pull-right">
            <a class='custom_pay' href="#inline_content"  ><button class="btn btn-lg btn-danger btn-block nomargin " id="toggle-form" value="submit" style="">Custom Payment</button></a>
           </div>
                </h3>
      </div>
            </div>
  </div>

<!-- pricing section-->
                <div class="pricing bottommargin clearfix">
                    <div class="container clear-bottommargin clearfix">
                        <div class="col-md-12 " >

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h4>We accept payment by</h4>
                                </div>
                                
                                <div class="pricing-features">
                                    <br>
                                 <img src="<?php echo base_url()?>assets/images/card_logo.png">
                                </div>
                            </div>
                        </div>
                    </div> 



                </div>
                <div class="content-wrap">
                    <div class="promo promo-dark promo-full landing-promo header-stick ">
                        <div class="container clearfix ">
                            <p style="color:#008000 ; margin:0 !important;"></p>
                            
                            <h3 style="margin-top:0px !important;" class="">
                                 Our Bank Account Details :
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
                    <!-- end-->


    <script language="javascript">
    document.onmousedown=disableclick;
    status="Right Click Disabled";
    function disableclick(event)
    {
      if(event.button==2)
       {
        //alert(status);
        // return false;    
       }
    }
    document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 67 || 
             e.keyCode === 86 || 
             e.keyCode === 85 || 
             e.keyCode === 117)) {
           // alert('not allowed');
           // return false;
        } else {
           // return false;
        }
};
    </script>



         