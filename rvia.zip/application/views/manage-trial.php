﻿<!-- #header end -->
<!-- Slider start -->
<section id="slider" class=" clearfix slider-height " >
<div class="swiper-container swiper-parent">
    <div class="swiper-wrapper">
        
         <div class="swiper-slide dark past-perform" >
            <div class="container clearfix">
               
            </div>
        </div> 
    </div>
  
  </div>
 
</section>

<!-- Content
        ============================================= -->
<section id="content">
          <div class="content-wrap">
    <div class="promo promo-dark promo-full landing-promo header-stick ">
              <div class="container clearfix ">
        <p style="color:#008000 ; margin:0 !important;">
                                  </p>
        <div class="vertical" style="display:none;">
                 
                </div>
        <h3 class="" style="margin-top:0px !important;">Call us @ <span>+91-731-4700447</span> or Email :<span>info@heavenresearchsecurity.com</span>
                  <div class="col_one_fifth col_last nobottommargin pull-right">
            <a class='inline' href="#inline_content"  ><button class="btn btn-lg btn-danger btn-block nomargin " id="toggle-form" value="submit" style="">Start Trial</button></a>
           </div>
                </h3>
      </div>
            </div>
  </div>

<!-- pricing section-->
                <div class="pricing bottommargin clearfix">
                    <div class="container clear-bottommargin clearfix">
                        <div class="col-md-12 " >

                            <div class="pricing-box">
                                <div class="pricing-title">
                                    <h2>Our past performance</h2>
                                </div>
                                
                                <div class="pricing-features pastrecord">
                                   
                                   <table   width="100%"> 
                                     <?php 
                                      
                                     ?>
                                        <tr>
                                            <td><a href=""><img src="<?php echo base_url();?>assets/images/excel.png" width="50px"> Stock Cash</a></td>
                                            <td><a href=""><img src="<?php echo base_url();?>assets/images/excel.png" width="50px"> Commodity</a> </td>
                                            <td><a href=""><img src="<?php echo base_url();?>assets/images/excel.png" width="50px"> Options</a></td>
                                            <td><a href=""><img src="<?php echo base_url();?>assets/images/excel.png" width="50px"> Forex</a></td>
                                        </tr>
                                         <tr>
                                            <td><a href=""><img src="<?php echo base_url();?>assets/images/excel.png" width="50px"> Stock Future</a></td>
                                            <td><a href=""><img src="<?php echo base_url();?>assets/images/excel.png" width="50px"> COMEX </a> </td>
                                            <td><a href=""><img src="<?php echo base_url();?>assets/images/excel.png" width="50px"> NCDEX </a></td>
                                            <td><a href=""><img src="<?php echo base_url();?>assets/images/excel.png" width="50px"> I/D-FOREX </a></td>
                                        </tr>
                                      </table>
                                </div>
                            </div>
                        </div>
                    </div> 



                </div>
                
            </div>
                    <!-- end-->


    <script language="javascript">
    document.onmousedown=disableclick;
    status="Right Click Disabled";
    function disableclick(event)
    {
      if(event.button==2)
       {
        //alert(status);
        // return false;    
       }
    }
    document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 67 || 
             e.keyCode === 86 || 
             e.keyCode === 85 || 
             e.keyCode === 117)) {
           // alert('not allowed');
           // return false;
        } else {
           // return false;
        }
};
    </script>



         